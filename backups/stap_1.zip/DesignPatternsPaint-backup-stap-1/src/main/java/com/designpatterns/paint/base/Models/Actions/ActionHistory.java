package com.designpatterns.paint.base.Models.Actions;

public class ActionHistory
{


}
