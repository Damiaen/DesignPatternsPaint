package com.designpatterns.paint.base.Models.Shapes.Figure;

public enum ShapeType
{
    Ellipse,
    Ornament,
    Rectangle
}
