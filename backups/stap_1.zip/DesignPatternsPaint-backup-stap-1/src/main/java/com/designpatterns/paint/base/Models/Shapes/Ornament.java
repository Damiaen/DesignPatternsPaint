package com.designpatterns.paint.base.Models.Shapes;

public class Ornament {
    // Implement ornament / bijschrift
}
