package com.designpatterns.paint.base.Models.Actions;

public class AddShape extends Action
{
    @Override
    void action() {
        super.action();
    }
}
