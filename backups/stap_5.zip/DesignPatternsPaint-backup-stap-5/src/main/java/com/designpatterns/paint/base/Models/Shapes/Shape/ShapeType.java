package com.designpatterns.paint.base.Models.Shapes.Shape;

public enum ShapeType
{
    Ellipse,
    Ornament,
    Rectangle,
    CompositeShape
}
