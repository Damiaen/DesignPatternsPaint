package com.designpatterns.paint.base.Models.Actions;

public class RemoveShape extends Action {
    @Override
    void action() {
        super.action();
    }
}
