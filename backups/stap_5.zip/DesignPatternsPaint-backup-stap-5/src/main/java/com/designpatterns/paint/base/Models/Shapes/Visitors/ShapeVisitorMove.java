//package com.designpatterns.paint.base.Models.Shapes.Visitors;
//
//import com.designpatterns.paint.base.Models.Shapes.Shape.Shape;
//
//public class ShapeVisitorMove implements ShapeVisitor {
//    public String visitShape(Shape shape) {
//        System.out.println("Move: " + shape.toString());
//        return shape.toString();
//    }
//}
