package com.designpatterns.paint.base.Models.Actions;

public class Merge extends Action{
    @Override
    void action() {
        super.action();
    }
}
