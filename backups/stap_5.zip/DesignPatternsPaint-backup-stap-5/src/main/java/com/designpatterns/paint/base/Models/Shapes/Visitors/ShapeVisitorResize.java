//package com.designpatterns.paint.base.Models.Shapes.Visitors;
//
//import com.designpatterns.paint.base.Models.Shapes.Shape.Shape;
//
//public class ShapeVisitorResize implements ShapeVisitor {
//    public String visitShape(Shape shape) {
//        System.out.println("Resize: " + shape.toString());
//        return shape.toString();
//    }
//}
