# DesignPaternsPaint
Teken programma voor Design Patterns
